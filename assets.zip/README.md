# Responsive Portfolio Website Rian
## [Watch it on youtube](https://youtu.be/-uQIBlaZ4P0)
### Responsive Portfolio Website Rian

- Responsive Personal Portfolio Website Using HTML CSS & JavaScript
- Contains animations when scrolling.
- Smooth scrolling in each section.
- Includes a dark & light theme.
- Sending emails in the contact section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
